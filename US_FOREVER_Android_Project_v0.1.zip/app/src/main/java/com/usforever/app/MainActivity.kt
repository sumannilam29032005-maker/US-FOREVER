package com.usforever.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08060D)
private val Purple = Color(0xFF9B4DFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { USForeverLogin() }
    }
}

@Composable
fun USForeverLogin() {
    var phone by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("US FOREVER", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("Together, privately.", color = Color.LightGray, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp, bottom = 36.dp))
            OutlinedTextField(
                value = phone,
                onValueChange = { if (it.length <= 15) phone = it.filter(Char::isDigit) },
                label = { Text("Phone number") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, focusedLabelColor = Purple, cursorColor = Purple)
            )
            Button(
                onClick = { message = if (phone.length >= 7) "OTP screen coming next." else "Enter a valid phone number." },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp).height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) { Text("GET OTP", fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { message = "Customer Care will be added in the next milestone." },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Customer Care") }
            if (message.isNotEmpty()) Text(message, color = Color.LightGray, modifier = Modifier.padding(top = 18.dp))
        }
    }
}
